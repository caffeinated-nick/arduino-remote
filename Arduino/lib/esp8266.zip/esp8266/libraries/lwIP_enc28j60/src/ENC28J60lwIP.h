
#ifndef _ENC28J60LWIP_H
#define _ENC28J60LWIP_H

#include <LwipIntfDev.h>
#include <utility/enc28j60.h>

using ENC28J60lwIP = LwipIntfDev<ENC28J60>;

#endif // _ENC28J60LWIP_H
